import React from 'react';
import Clicker  from "./Clicker";
import ButtonGroup from "./ButtonGroup";
import Counter from "./Counter";
import NumberGame from "./NumberGame";
import './App.css';

function App() {
  return (
    <div>
        {/*<ButtonGroup />*/}

        {/*<Counter />*/}
      {/*<Clicker />*/}
      {/*<Clicker />*/}
      {/*<Clicker />*/}

        <NumberGame />
    </div>
  );
}

export default App;
